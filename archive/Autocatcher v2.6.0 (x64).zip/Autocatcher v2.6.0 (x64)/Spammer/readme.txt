Launch it, then go to : "http://localhost:8080/"
Nothing will appear in the black window.